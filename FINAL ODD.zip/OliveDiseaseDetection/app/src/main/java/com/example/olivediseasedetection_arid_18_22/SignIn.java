package com.example.olivediseasedetection_arid_18_22;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;


public class SignIn extends AppCompatActivity {
    private TextView v_tv_register;
    private EditText v_et_p_no, v_et_p_word;
    private Button v_btn_login;
    String e_mail_ts;
    String e_mail_t;
    private FirebaseAuth auth;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);
        auth = FirebaseAuth.getInstance();

        v_btn_login = findViewById(R.id.btn_Login);
        v_et_p_no = findViewById(R.id.et_username_login);
        v_et_p_word = findViewById(R.id.et_password_login);
        v_tv_register = findViewById(R.id.tv_create_new_account);
        e_mail_ts = v_et_p_no.getText().toString().trim();
        v_btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    {
                        e_mail_t = v_et_p_no.getText().toString();
                        String pass_code_t = v_et_p_word.getText().toString();
                        if(e_mail_t.isEmpty()){
                            v_et_p_no.setError("Email is required!");
                            v_et_p_word.requestFocus();
                            return;
                        }
                        if(!Patterns.EMAIL_ADDRESS.matcher(e_mail_t).matches()){
                            v_et_p_no.setError("Please enter a valid email");
                            v_et_p_no.requestFocus();
                            return;
                        }
                        if(pass_code_t.isEmpty()){
                            v_et_p_word.setError("Password is required!");
                            v_et_p_word.requestFocus();
                            return;
                        }
                        if(pass_code_t.length() < 6){
                            v_et_p_word.setError("Minimum password length is 6 characters!");
                            v_et_p_word.requestFocus();
                            return;
                        }
                        else{
                            auth.signInWithEmailAndPassword(e_mail_t,pass_code_t).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {
                                    if (task.isSuccessful())
                                    {
                                        Toast.makeText(SignIn.this, "User Login Successfully", Toast.LENGTH_SHORT).show();
                                        startActivity(new Intent(SignIn.this,MainActivity.class));
                                        finish();
                                    }
                                    else{
                                        Toast.makeText(SignIn.this, "Error in Login", Toast.LENGTH_SHORT).show();
                                    }
                                }
                            });
                        }


                    }
                }
        });

        v_tv_register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(SignIn.this, SignUp.class));
            }
        });

    }

    public void tv_fg_password(View view) {
        Toast.makeText(SignIn.this, "", Toast.LENGTH_SHORT).show();
    }
}
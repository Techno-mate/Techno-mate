package com.example.olivediseasedetection_arid_18_22;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;


public class SignUp extends AppCompatActivity {

    private TextView banner,v_aracc;
    Button btn_create_account;
    private EditText name,email,phno,password,conpassword;
    private ProgressBar progressBar;
    FirebaseDatabase rootnode;

    private FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        name =  findViewById(R.id.tv_create_account_FirstName);
        email =  findViewById(R.id.tv_create_account_Email);
        password =  findViewById(R.id.tv_create_account_pw);
        conpassword =  findViewById(R.id.tv_create_account_conform_pw);
        v_aracc =  findViewById(R.id.tv_already_have_ac);
        btn_create_account = findViewById(R.id.btn_create_account);
        v_aracc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), SignIn.class);
                startActivity(i);
                SignUp.this.finish();

            }
        });


        btn_create_account.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                auth = FirebaseAuth.getInstance();

                    final String mail_t = email.getText().toString();
                    String passcode_t = password.getText().toString();
                    String conpascode = conpassword.getText().toString();
                    final String myname = name.getText().toString();
                    if (myname.isEmpty()) {
                        name.setError("Full Name is Required");
                        name.requestFocus();
                        return;
                    } else if (mail_t.isEmpty()) {
                        email.setError("Email is Required");
                        email.requestFocus();
                        return;
                    } else if (!Patterns.EMAIL_ADDRESS.matcher(mail_t).matches()) {
                        email.setError("Please provide valid email");
                        email.requestFocus();
                        return;
                    } else if (passcode_t.isEmpty()) {
                        password.setError("Password is Required");
                        password.requestFocus();
                        return;
                    } else if (passcode_t.length() < 6) {
                        password.setError("Minimum password length should be 6 characters!");
                        password.requestFocus();
                        return;
                    } else if (conpascode.isEmpty()) {
                        conpassword.setError("Confirm Password is Required");
                        conpassword.requestFocus();
                        return;
                    } else if (!conpascode.equals(passcode_t)) {
                        conpassword.setError("Confirm Password does not matches with password");
                        conpassword.requestFocus();
                        return;
                    }
                    else {
                        auth.createUserWithEmailAndPassword(mail_t,passcode_t).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task)
                            {
                                if (task.isSuccessful())
                                {
                                    Toast.makeText(SignUp.this, "User Register Successfully", Toast.LENGTH_SHORT).show();
                                    startActivity(new Intent(SignUp.this, MainActivity.class));
                                    finish();
                                }
                                else
                                {
                                    Toast.makeText(SignUp.this, "Error in Login", Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
                    }

            }
        });


    }
}
package com.example.olivediseasedetection_arid_18_22;

import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Forgot_password extends AppCompatActivity {
    private EditText emaill;
    private Button resetbtn;
    private ProgressBar progressBar;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);
        emaill = (EditText)findViewById(R.id.mail);
        resetbtn = (Button)findViewById(R.id.reset);
        progressBar = (ProgressBar)findViewById(R.id.pbar);
        resetbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resetPassword();
            }
        });
    }
    private void resetPassword() {


        Toast.makeText(Forgot_password.this,"Try again! Something wrong happened!",Toast.LENGTH_LONG).show();
    }}
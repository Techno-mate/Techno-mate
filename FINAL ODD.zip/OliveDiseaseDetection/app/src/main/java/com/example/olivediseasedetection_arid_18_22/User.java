package com.example.olivediseasedetection_arid_18_22;

public class User {

    public String name, email;

    public User() {

    }

    public User(String name, String email) {
        this.name = name;
        this.email = email;
    }
}
